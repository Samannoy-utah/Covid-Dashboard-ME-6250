# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 03:21:56 2022

@author: Samannoy and Jared
"""
## This function is used to customize the div tag of the embedded plots
## by adding the style css inside the div tag

def displayTypeEdit(div, display):
    if display=='show':
        string=' style="display:block"'
    elif display=='hide':
        string=' style="display:none"'
    res=div[:-7]+ string + div[-7:]
    return res