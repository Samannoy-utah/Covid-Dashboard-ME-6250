# -*- coding: utf-8 -*-
"""
Created on Sat Dec 10 19:11:03 2022

@author: Samannoy and Jared
"""

## The main file for running and generating the plots and embedding in an HTML file

import readJSON as rj
import pandas as pd

from bokeh.models import DatetimeTickFormatter, HoverTool, ColumnDataSource, DateRangeSlider
from bokeh.plotting import figure, show
from bokeh.io import curdoc
from bokeh.layouts import row, gridplot, layout
from bokeh.embed import components
import os

# Custom modules to import
import Multi_country_plotter as mp
import Single_country_plotter as sp
import displayTypeEdit as disp
import hideShow as hs


########################################
### Py implementation for Bokeh#########

# Multi country plotting
## Total data
scriptmultitotalstd, divmultitotalstd = mp.Multi_country_plotter('total','std')
scriptmultitotalnorm, divmultitotalnorm = mp.Multi_country_plotter('total','norm')
## Daily data
scriptmultidailystd, divmultidailystd = mp.Multi_country_plotter('daily','std')
scriptmultidailynorm, divmultidailynorm = mp.Multi_country_plotter('daily','norm')

# Loop to generate all country div tags and customize the visibility to show usa and hide rest
## Loop to implement total deaths
scriptListTotal=[]
divListTotal=[]
div_dictionaryTotal={}
try:
    for f in os.listdir():
        if f[-8:-5]=='usa':
            scriptTotal_usa, divTotal_usa=sp.Single_country_plotter(f,'total','std')
            id=divTotal_usa.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryTotal[country]=id
            divTotal_usa=disp.displayTypeEdit(divTotal_usa, 'show')
        elif f[-8:-5]!='usa' and f[-9:-5]!='List' and f[-9:-5]!='mple' and f[-5:]=='.json' or f[-5:]=='.JSON':
            # print(f)
            scriptTotal, divTotal=sp.Single_country_plotter(f,'total','std')
            scriptListTotal.append(scriptTotal)
            id=divTotal.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryTotal[country]=id
            divTotal=disp.displayTypeEdit(divTotal, 'hide')
            divListTotal.append(divTotal)
except:
    print(f'Error found in {country}') 
# Loop to implement normalized total deaths
scriptListTotalnorm=[]
divListTotalnorm=[]
div_dictionaryTotalnorm={}
try:  
    for f in os.listdir():
        if f[-8:-5]=='usa':
            scriptTotalnorm_usa, divTotalnorm_usa=sp.Single_country_plotter(f,'total','norm')
            id=divTotalnorm_usa.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryTotalnorm[country]=id
            divTotalnorm_usa=disp.displayTypeEdit(divTotalnorm_usa, 'show')
        elif f[-8:-5]!='usa' and f[-9:-5]!='List' and f[-9:-5]!='mple' and f[-5:]=='.json' or f[-5:]=='.JSON':
            # print(f)
            scriptTotalnorm, divTotalnorm=sp.Single_country_plotter(f,'total','norm')
            scriptListTotalnorm.append(scriptTotalnorm)
            id=divTotalnorm.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryTotalnorm[country]=id
            divTotalnorm=disp.displayTypeEdit(divTotalnorm, 'hide')
            divListTotalnorm.append(divTotalnorm)
except:
    print(f'Error found in {country}') 

## Loop to implement daily deaths
scriptListDaily=[]
divListDaily=[]
div_dictionaryDaily={}
try:
    for f in os.listdir():
        if f[-8:-5]=='usa':
            scriptDaily_usa, divDaily_usa=sp.Single_country_plotter(f,'daily','std')
            id=divDaily_usa.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryDaily[country]=id
            divDaily_usa=disp.displayTypeEdit(divDaily_usa, 'show')
        elif f[-8:-5]!='usa' and f[-5:]=='.json' or f[-5:]=='.JSON':
            # print(f)
            scriptDaily, divDaily=sp.Single_country_plotter(f,'daily','std')
            scriptListDaily.append(scriptDaily)
            id=divDaily.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryDaily[country]=id
            divDaily=disp.displayTypeEdit(divDaily, 'hide')
            divListDaily.append(divDaily)
except:
    print(f'Error found in {country}') 

        
# Loop to implement normalized daily deaths
scriptListDailynorm=[]
divListDailynorm=[]
div_dictionaryDailynorm={}
try:
    for f in os.listdir():
        if f[-8:-5]=='usa':
            scriptDailynorm_usa, divDailynorm_usa=sp.Single_country_plotter(f,'daily','norm')
            id=divDailynorm_usa.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryDailynorm[country]=id
            divDailynorm_usa=disp.displayTypeEdit(divDailynorm_usa, 'show')
        elif f[-8:-5]!='usa' and f[-9:-5]!='List' and f[-9:-5]!='mple' and f[-5:]=='.json' or f[-5:]=='.JSON':
            # print(f)
            scriptDailynorm, divDailynorm=sp.Single_country_plotter(f,'daily','norm')
            scriptListDailynorm.append(scriptDailynorm)
            id=divDailynorm.split('"')[3]
            c=f.split("_")[1]
            country=c[:-5]
            div_dictionaryDailynorm[country]=id
            divDailynorm=disp.displayTypeEdit(divDailynorm, 'hide')
            divListDailynorm.append(divDailynorm)
except:
    print(f'Error found in {country}') 




## script tag to implement hide and show functionality in total deaths##
retTotal=""  #Variable that stores the hide show script implemented later
for c in div_dictionaryTotal:
    retTotal=retTotal+hs.hideShow2(c, div_dictionaryTotal)
    
## script tag to implement hide and show functionality in total deaths normalized##
retTotalnorm=""  #Variable that stores the hide show script implemented later
for c in div_dictionaryTotalnorm:
    retTotalnorm=retTotalnorm+hs.hideShow2(c, div_dictionaryTotalnorm)



## script tag to implement hide and show functionality in total deaths##
retDaily=""  #Variable that stores the hide show script implemented later
for c in div_dictionaryDaily:
    retDaily=retDaily+hs.hideShow2(c, div_dictionaryDaily)
    
## script tag to implement hide and show functionality in daily deaths normalized##
retDailynorm=""  #Variable that stores the hide show script implemented later
for c in div_dictionaryDailynorm:
    retDailynorm=retDailynorm+hs.hideShow2(c, div_dictionaryDailynorm)







########################################
# Creating the HTML file
file_html = open("HTML files\\CovidDashboard_Samannoy_Jared.html", "w")
# Adding the input data to the HTML file
file_html.write('''<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Covid Dashboard</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="jquery-jvectormap-2.0.5/jquery-jvectormap-2.0.5.css" type="text/css" media="screen"/>
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/Covid19.png" />
    <!-- JQuery CDN-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <!-- JS JSON-->
    
    <script type="text/javascript" src="javascript.js"></script>
  </head>''')
  
file_html.write('''<body onload="populateSelect();constructTable('#table');">
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
            <h4 class="mb-0 font-weight-normal"><b>Covid Dashboard</b></h4>
          
        </div>
        <ul class="nav">
          <li class="nav-item profile">
            <div class="profile-desc">
              <div class="profile-pic">
                
                <div class="profile-name">
                  <h5 class="mb-0 font-weight-normal">Samannoy and Jared</h5>
                  <span>Fall 2022</span>
                </div>
              </div>

            </div>
          </li>
          <li class="nav-item nav-category">
            <span class="nav-link">Navigation</span>
          </li>
          <li class="nav-item menu-items">
            <a class="nav-link" >
              <span class="menu-icon">
                <i class="mdi mdi-earth"></i>
              </span>
              <label class="menu-title text-warning">Chosen country</label>
            </a>
          </li>
          <li>
            <span> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>
            <label id="Chosen_country"class="menu-title text-success"></label>
            
          </li>

          <li class="nav-item menu-items">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <span class="menu-icon">
                <i class="mdi mdi-earth"></i>
              </span>
              <span class="menu-title">Country List</span>
              <i class="menu-arrow"></i>
            </a>
          </li>
          <li>
            <span> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>
            <select class="btn btn-outline-secondary btn-md " id="sel" onchange="show(this)">
              <option class="nav-link" value="">-- Select --</option>
          </select>
          </li>
          <li>
            <span> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>
            <button class="btn btn-outline-secondary btn-md" type="button" onclick='update()'>Go</button>
          </li>
        
        </ul>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_navbar.html -->
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-sm-6 grid-margin"> <!-- Can be removed-->
                <div class="card">
                  <div class="card-body">
                    ''')
file_html.write(divTotal_usa)
for i in range(len(divListTotal)):
    file_html.write(divListTotal[i])
    
file_html.write('''
                  </div>
                </div>
              </div>
               <div class="col-sm-6 grid-margin">
                <div class="card">
                  <div class="card-body">
                    ''')
                    
file_html.write(divTotalnorm_usa)
for i in range(len(divListTotalnorm)):
    file_html.write(divListTotalnorm[i])
    
file_html.write('''</div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6 grid-margin"> <!-- Can be removed-->
                <div class="card">
                  <div class="card-body">
                    ''')
file_html.write(divDaily_usa)
for i in range(len(divListDaily)):
    file_html.write(divListDaily[i])
    
file_html.write('''
                  </div>
                </div>
              </div>
               <div class="col-sm-6 grid-margin">
                <div class="card">
                  <div class="card-body">
                    ''')
                    
file_html.write(divDailynorm_usa)
for i in range(len(divListDailynorm)):
    file_html.write(divListDailynorm[i])
    
file_html.write('''</div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6 grid-margin">
            <h3 style="display:inline" class="card-title">Data of 4 countries with highest deaths</h3>
            </div></div>
            <div class="row">
              <div class="col-sm-6 grid-margin">
                <div class="card">
                  <div class="card-body">''')
file_html.write(divmultitotalstd)
file_html.write('''
                </div>
                </div>
              </div>
               <div class="col-sm-6 grid-margin">
                <div class="card">
                  <div class="card-body">''')
file_html.write(divmultitotalnorm)
file_html.write('''                
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-6 grid-margin">
                <div class="card">
                  <div class="card-body">''')
file_html.write(divmultidailystd)
file_html.write('''
                </div>
                </div>
              </div>
               <div class="col-sm-6 grid-margin">
                <div class="card">
                  <div class="card-body">''')
file_html.write(divmultidailynorm)
file_html.write('''                
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    <h5 style="display:inline" class="card-title">Total Deaths by Countries till date: </h5><h5 id="date" style="display:inline"></h5>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="table-responsive">
                          <table id="table" class="table">
                            <thead>
                              <tr >
                                <th> </th>
                                <th class="text-success"> Country </th>
                                <th style="transform:translateX(85px)" class="text-danger">  Total deaths </th>
                                <th style="transform:translateX(100px)" class="text-danger">  Total deaths / 1M pop</th>
                              </tr>
                            </thead>
                            
                          </table>
                        </div>
                      </div>
                      <div class="col-md-7">
                        <div id="world-map" class="vector-map"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div>
              
              
              <br><br>
              
              
              
            </div>
          <!-- content-wrapper ends -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
 
    <script src="jquery-jvectormap-2.0.5/jquery-jvectormap-2.0.5.min.js"></script>
    <script src="jquery-jvectormap-2.0.5/jquery-jvectormap-world-mill.js"></script>
    
    <!-- endinject -->
    <!-- Custom js for this page -->

    <!-- Js for bokeh -->
    <script src="assets/js/dashboard.js"></script>
    <script src="https://cdn.bokeh.org/bokeh/release/bokeh-2.4.0.min.js"
        crossorigin="anonymous"></script>
<script src="https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.4.0.min.js"
        crossorigin="anonymous"></script>
<script src="https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.4.0.min.js"
        crossorigin="anonymous"></script>
<script src="https://cdn.bokeh.org/bokeh/release/bokeh-gl-2.4.0.min.js"
        crossorigin="anonymous"></script>
<script src="https://cdn.bokeh.org/bokeh/release/bokeh-mathjax-2.4.0.min.js"
        crossorigin="anonymous"></script>

''')
        
# Add all embedded scripts here for Bokeh
file_html.write(scriptTotal_usa)
file_html.write(scriptTotalnorm_usa)
file_html.write(scriptDaily_usa)
file_html.write(scriptDailynorm_usa) 
file_html.write(scriptmultitotalstd)         
file_html.write(scriptmultitotalnorm)
file_html.write(scriptmultidailystd)         
file_html.write(scriptmultidailynorm)


for i in range(len(scriptListTotal)):
    file_html.write(scriptListTotal[i])     
    
for i in range(len(scriptListTotalnorm)):
    file_html.write(scriptListTotalnorm[i])      
    
for i in range(len(scriptListDaily)):
    file_html.write(scriptListDaily[i])     
    
for i in range(len(scriptListDailynorm)):
    file_html.write(scriptListDailynorm[i])  
                
file_html.write('''<script>
          function update(){''')
                            
# functions that write the JS code for controlling the dropdown menu
file_html.write(retTotal)
file_html.write(retTotalnorm)
file_html.write(retDaily)
file_html.write(retDailynorm)

file_html.write(''' if (document.getElementById('Chosen_country').innerHTML=="vietnam"){alert('No data found');}}
          </script>
          <script>
            function populateSelect() {
              // the json.
              let countries = [{"ID":0,"Countries":"usa"},{"ID":1,"Countries":"india"},{"ID":2,"Countries":"france"},{"ID":3,"Countries":"germany"},{"ID":4,"Countries":"brazil"},{"ID":5,"Countries":"s. korea"},{"ID":6,"Countries":"japan"},{"ID":7,"Countries":"italy"},{"ID":8,"Countries":"uk"},{"ID":9,"Countries":"russia"},{"ID":10,"Countries":"turkey"},{"ID":11,"Countries":"spain"},{"ID":12,"Countries":"vietnam"},{"ID":13,"Countries":"australia"},{"ID":14,"Countries":"argentina"},{"ID":15,"Countries":"netherlands"},{"ID":16,"Countries":"taiwan"},{"ID":17,"Countries":"iran"},{"ID":18,"Countries":"mexico"},{"ID":19,"Countries":"indonesia"},{"ID":20,"Countries":"poland"},{"ID":21,"Countries":"colombia"},{"ID":22,"Countries":"austria"},{"ID":23,"Countries":"portugal"},{"ID":24,"Countries":"greece"},{"ID":25,"Countries":"ukraine"},{"ID":26,"Countries":"malaysia"},{"ID":27,"Countries":"chile"},{"ID":28,"Countries":"dprk"},{"ID":29,"Countries":"israel"},{"ID":30,"Countries":"thailand"},{"ID":31,"Countries":"belgium"},{"ID":32,"Countries":"czechia"},{"ID":33,"Countries":"canada"},{"ID":34,"Countries":"switzerland"},{"ID":35,"Countries":"peru"},{"ID":36,"Countries":"south africa"},{"ID":37,"Countries":"philippines"},{"ID":38,"Countries":"romania"},{"ID":39,"Countries":"denmark"},{"ID":40,"Countries":"sweden"},{"ID":41,"Countries":"iraq"},{"ID":42,"Countries":"serbia"},{"ID":43,"Countries":"singapore"},{"ID":44,"Countries":"hungary"},{"ID":45,"Countries":"hong kong"},{"ID":46,"Countries":"bangladesh"},{"ID":47,"Countries":"new zealand"},{"ID":48,"Countries":"slovakia"},{"ID":49,"Countries":"georgia"},{"ID":50,"Countries":"jordan"},{"ID":51,"Countries":"ireland"},{"ID":52,"Countries":"pakistan"},{"ID":53,"Countries":"norway"},{"ID":54,"Countries":"finland"},{"ID":55,"Countries":"kazakhstan"},{"ID":56,"Countries":"bulgaria"},{"ID":57,"Countries":"lithuania"},{"ID":58,"Countries":"morocco"},{"ID":59,"Countries":"slovenia"},{"ID":60,"Countries":"croatia"},{"ID":61,"Countries":"lebanon"},{"ID":62,"Countries":"guatemala"},{"ID":63,"Countries":"costa rica"},{"ID":64,"Countries":"tunisia"},{"ID":65,"Countries":"bolivia"},{"ID":66,"Countries":"cuba"},{"ID":67,"Countries":"uae"},{"ID":68,"Countries":"ecuador"},{"ID":69,"Countries":"panama"},{"ID":70,"Countries":"nepal"},{"ID":71,"Countries":"belarus"},{"ID":72,"Countries":"uruguay"},{"ID":73,"Countries":"mongolia"},{"ID":74,"Countries":"latvia"},{"ID":75,"Countries":"saudi arabia"},{"ID":76,"Countries":"azerbaijan"},{"ID":77,"Countries":"paraguay"},{"ID":78,"Countries":"bahrain"},{"ID":79,"Countries":"sri lanka"},{"ID":80,"Countries":"kuwait"},{"ID":81,"Countries":"dominican republic"},{"ID":82,"Countries":"myanmar"},{"ID":83,"Countries":"palestine"},{"ID":84,"Countries":"cyprus"},{"ID":85,"Countries":"estonia"},{"ID":86,"Countries":"moldova"},{"ID":87,"Countries":"venezuela"},{"ID":88,"Countries":"egypt"},{"ID":89,"Countries":"libya"},{"ID":90,"Countries":"ethiopia"},{"ID":91,"Countries":"qatar"},{"ID":92,"Countries":"r\u00e9union"},{"ID":93,"Countries":"honduras"},{"ID":94,"Countries":"armenia"},{"ID":95,"Countries":"bosnia and herzegovina"},{"ID":96,"Countries":"oman"},{"ID":97,"Countries":"north macedonia"},{"ID":98,"Countries":"kenya"},{"ID":99,"Countries":"zambia"},{"ID":100,"Countries":"albania"},{"ID":101,"Countries":"botswana"},{"ID":102,"Countries":"luxembourg"},{"ID":103,"Countries":"montenegro"},{"ID":104,"Countries":"algeria"},{"ID":105,"Countries":"nigeria"},{"ID":106,"Countries":"zimbabwe"},{"ID":107,"Countries":"uzbekistan"},{"ID":108,"Countries":"brunei "},{"ID":109,"Countries":"mozambique"},{"ID":110,"Countries":"martinique"},{"ID":111,"Countries":"laos"},{"ID":112,"Countries":"iceland"},{"ID":113,"Countries":"kyrgyzstan"},{"ID":114,"Countries":"afghanistan"},{"ID":115,"Countries":"el salvador"},{"ID":116,"Countries":"guadeloupe"},{"ID":117,"Countries":"maldives"},{"ID":118,"Countries":"trinidad and tobago"},{"ID":119,"Countries":"ghana"},{"ID":120,"Countries":"namibia"},{"ID":121,"Countries":"uganda"},{"ID":122,"Countries":"jamaica"},{"ID":123,"Countries":"cambodia"},{"ID":124,"Countries":"rwanda"},{"ID":125,"Countries":"cameroon"},{"ID":126,"Countries":"malta"},{"ID":127,"Countries":"angola"},{"ID":128,"Countries":"barbados"},{"ID":129,"Countries":"french guiana"},{"ID":130,"Countries":"channel islands"},{"ID":131,"Countries":"drc"},{"ID":132,"Countries":"senegal"},{"ID":133,"Countries":"malawi"},{"ID":134,"Countries":"ivory coast"},{"ID":135,"Countries":"suriname"},{"ID":136,"Countries":"french polynesia"},{"ID":137,"Countries":"new caledonia"},{"ID":138,"Countries":"eswatini"},{"ID":139,"Countries":"guyana"},{"ID":140,"Countries":"belize"},{"ID":141,"Countries":"fiji"},{"ID":142,"Countries":"madagascar"},{"ID":143,"Countries":"sudan"},{"ID":144,"Countries":"mauritania"},{"ID":145,"Countries":"cabo verde"},{"ID":146,"Countries":"bhutan"},{"ID":147,"Countries":"syria"},{"ID":148,"Countries":"burundi"},{"ID":149,"Countries":"seychelles"},{"ID":150,"Countries":"gabon"},{"ID":151,"Countries":"andorra"},{"ID":152,"Countries":"papua new guinea"},{"ID":153,"Countries":"cura\u00e7ao"},{"ID":154,"Countries":"aruba"},{"ID":155,"Countries":"mayotte"},{"ID":156,"Countries":"mauritius"},{"ID":157,"Countries":"tanzania"},{"ID":158,"Countries":"togo"},{"ID":159,"Countries":"guinea"},{"ID":160,"Countries":"isle of man"},{"ID":161,"Countries":"bahamas"},{"ID":162,"Countries":"faeroe islands"},{"ID":163,"Countries":"lesotho"},{"ID":164,"Countries":"haiti"},{"ID":165,"Countries":"mali"},{"ID":166,"Countries":"cayman islands"},{"ID":167,"Countries":"saint lucia"},{"ID":168,"Countries":"benin"},{"ID":169,"Countries":"somalia"},{"ID":170,"Countries":"congo"},{"ID":171,"Countries":"solomon islands"},{"ID":172,"Countries":"timor-leste"},{"ID":173,"Countries":"micronesia"},{"ID":174,"Countries":"san marino"},{"ID":175,"Countries":"burkina faso"},{"ID":176,"Countries":"liechtenstein"},{"ID":177,"Countries":"gibraltar"},{"ID":178,"Countries":"grenada"},{"ID":179,"Countries":"bermuda"},{"ID":180,"Countries":"nicaragua"},{"ID":181,"Countries":"south sudan"},{"ID":182,"Countries":"tajikistan"},{"ID":183,"Countries":"equatorial guinea"},{"ID":184,"Countries":"tonga"},{"ID":185,"Countries":"samoa"},{"ID":186,"Countries":"dominica"},{"ID":187,"Countries":"djibouti"},{"ID":188,"Countries":"marshall islands"},{"ID":189,"Countries":"monaco"},{"ID":190,"Countries":"car"},{"ID":191,"Countries":"gambia"},{"ID":192,"Countries":"saint martin"},{"ID":193,"Countries":"greenland"},{"ID":194,"Countries":"vanuatu"},{"ID":195,"Countries":"yemen"},{"ID":196,"Countries":"caribbean netherlands"},{"ID":197,"Countries":"sint maarten"},{"ID":198,"Countries":"eritrea"},{"ID":199,"Countries":"niger"},{"ID":200,"Countries":"antigua and barbuda"},{"ID":201,"Countries":"comoros"},{"ID":202,"Countries":"guinea-bissau"},{"ID":203,"Countries":"liberia"},{"ID":204,"Countries":"sierra leone"},{"ID":205,"Countries":"chad"},{"ID":206,"Countries":"british virgin islands"},{"ID":207,"Countries":"st. vincent grenadines"},{"ID":208,"Countries":"saint kitts and nevis"},{"ID":209,"Countries":"turks and caicos"},{"ID":210,"Countries":"cook islands"},{"ID":211,"Countries":"sao tome and principe"},{"ID":212,"Countries":"palau"},{"ID":213,"Countries":"st. barth"},{"ID":214,"Countries":"nauru"},{"ID":215,"Countries":"anguilla"},{"ID":216,"Countries":"kiribati"},{"ID":217,"Countries":"saint pierre miquelon"},{"ID":218,"Countries":"tuvalu"},{"ID":219,"Countries":"falkland islands"},{"ID":220,"Countries":"saint helena"},{"ID":221,"Countries":"montserrat"},{"ID":222,"Countries":"macao"},{"ID":223,"Countries":"wallis and futuna"},{"ID":224,"Countries":"niue"},{"ID":225,"Countries":"vatican city"},{"ID":226,"Countries":"western sahara"},{"ID":227,"Countries":"china"}];
          
              let ele = document.getElementById('sel');
              for (let i = 0; i < countries.length; i++) {
                // populate select element with json.
                ele.innerHTML = ele.innerHTML +
                  '<option value="' + countries[i]['ID'] + '">' + countries[i]['Countries'].toLocaleUpperCase() + '</option>';
              }
            }
          
            function show(ele) {
              // get the selected value from <select> element and show it.
              let msg = document.getElementById('Chosen_country');
              msg.innerHTML = ele.options[ele.selectedIndex].text.toLocaleLowerCase();
            }
          </script>
          
	

	<script>
		var list = [{"Country":"usa","TotalDeaths":1109394,"TotalDeathsNorm":3304},
    {"Country":"brazil","TotalDeaths":690739,"TotalDeathsNorm":3194},
    {"Country":"india","TotalDeaths":530653,"TotalDeathsNorm":375},
    {"Country":"russia","TotalDeaths":392454,"TotalDeathsNorm":2686},
    {"Country":"mexico","TotalDeaths":330633,"TotalDeathsNorm":2500},
    {"Country":"peru","TotalDeaths":217604,"TotalDeathsNorm":6383}];
			
		function constructTable(selector) {
			
			// Getting the all column names
			var cols = Headers(list, selector);

			// Traversing the JSON data
			for (var i = 0; i < list.length; i++) {
				var row = $('<tr/>');
				for (var colIndex = 0; colIndex < cols.length; colIndex++)
				{
					var val = list[i][cols[colIndex]];
					
					// If there is any key, which is matching
					// with the column name
          row.append('<td/>');
					if (val == null) val = "";
						row.append($('<td/>').html(val));
				}
				
				// Adding each row to the table
				$(selector).append(row);
			}
		}
		
		function Headers(list, selector) {
			var columns = [];
			var header = $('<tr/>');
			
			for (var i = 0; i < list.length; i++) {
				var row = list[i];
				
				for (var k in row) {
					if ($.inArray(k, columns) == -1) {
						columns.push(k);
						
						// Creating the header
						//header.append($('<th/>').html(k));
					}
				}
			}
			
			// Appending the header to the table
			$(selector).append(header);
				return columns;
		}	
	</script>

     <script>
        // JS Code to fetch current date
      date = new Date();
      year = date.getFullYear();
      month = date.getMonth() + 1;
      day = date.getDate();
      document.getElementById("date").innerHTML = month + "/" + day + "/" + year;
      </script>

    <script>
      // JS script to color code world map
      var colorData = {
        "US": 200,
          "BR": 200,
          "IN": 200,
          "RU": 200,
          "MX": 200,
          "PE": 200,
      };
  
      $(function(){
        $('#world-map').vectorMap({
          map: 'world_mill',
          series: {
            regions: [{
              values: colorData,
              scale: ['#C8EEFF', '#0071A4'],
              normalizeFunction: 'polynomial'
            }]
          },
          onRegionTipShow: function(e, el, code){
            el.html(el.html());
          }
        });
      });
  
    </script>


    <!-- End custom js for this page -->
  </body>
</html>''')
# Saving the data into the HTML file
file_html.close()