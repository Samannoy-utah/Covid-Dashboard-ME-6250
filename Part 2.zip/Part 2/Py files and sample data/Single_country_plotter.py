# -*- coding: utf-8 -*-
"""
Created on Sat Dec 10 12:33:37 2022

@author: Samannoy and Jared
"""

## This function plots the data of a single country based on the parameters
## std and norm are the 2 types of plots returnable alongside the other parameter
## which specifies the data type: total deaths or daily deaths info

def Single_country_plotter(fileName,plot_type,param):
    import readJSON as rj
    import pandas as pd
    
    from bokeh.models import DatetimeTickFormatter, HoverTool, ColumnDataSource, DateRangeSlider
    from bokeh.plotting import figure, show
    from bokeh.io import curdoc
    from bokeh.embed import components
    from bokeh.layouts import row, gridplot, layout
    
    
    df = rj.readJSON(fileName)
    df.Dates = pd.to_datetime(df.Dates,format='%b%d,%Y')    #format the dates from strings
    source = ColumnDataSource(df)
    
    name=fileName.split('_')
    country_name_json=name[1]
    country_name=country_name_json[:-5].capitalize()
    curdoc().theme = 'light_minimal'
    #choose theme
    try:
        if plot_type=='total':
            if param=='std':
                p1 = figure(
                    title='Cumulative Deaths in '+country_name.upper(),
                    x_axis_label='Date',
                    y_axis_label='Deaths',
                    x_axis_type="datetime"
                )
                totalDeaths = p1.line(
                    x='Dates',
                    y='TotalDeaths',
                    source=source,
                    legend_label=country_name.upper(),
                    color='blue',
                    line_width=2
                )
                
            elif param=='norm':
                p1 = figure(
                    title='Cumulative Deaths per 1M in '+country_name.upper(),
                    x_axis_label='Date',
                    y_axis_label='Deaths per 1M',
                    x_axis_type="datetime"
                )
                totalDeaths = p1.line(
                    x='Dates',
                    y='TotalDeathsNormalized',
                    source=source,
                    legend_label=country_name.upper(),
                    color='green',
                    line_width=2
                )
        elif plot_type=='daily':
            if param=='std':
                p1 = figure(
                    title='Daily Deaths in '+country_name.upper(),
                    x_axis_label='Date',
                    y_axis_label='Deaths',
                    x_axis_type="datetime"
                )
                totalDeaths = p1.line(
                    x='Dates',
                    y='DailyDeaths',
                    source=source,
                    legend_label=country_name.upper(),
                    color='black',
                    line_width=1
                )
                
            elif param=='norm':
                p1 = figure(
                    title='Daily Deaths per 1M in '+country_name.upper(),
                    x_axis_label='Date',
                    y_axis_label='Deaths per 1M',
                    x_axis_type="datetime"
                )
                totalDeaths = p1.line(
                    x='Dates',
                    y='DailyDeathsNormalized',
                    source=source,
                    legend_label=country_name.upper(),
                    color='maroon',
                    line_width=1
                )
    
        
        # autohide the toolbar
        p1.toolbar.autohide = True
     
        p1.add_tools(HoverTool(tooltips=('@Dates{%b %e, %Y}: @TotalDeaths'),
                  formatters={'@Dates': 'datetime'}))
    
    
        p1.xaxis[0].formatter = DatetimeTickFormatter(months="%b %e, %Y")
    
        # customize the legend and align to top left
        p1.legend.location = "top_left"
        p1.legend.border_line_width = 2
        p1.legend.border_line_color = "black"
        p1.legend.border_line_alpha = 0.8
        
        # Design the Title text
        p1.title.align = "center"
        p1.title.text_color = "black"
        p1.title.text_font_size = "20px"
        p1.title.background_fill_color = "white"
        
        # Customize the axes labels
        p1.xaxis.axis_label_text_color="black"
        p1.xaxis.axis_label_text_font_size = "15px"
        p1.xaxis.axis_label_text_font_style = "bold"
        
        p1.yaxis.axis_label_text_color="black"
        p1.yaxis.axis_label_text_font_size = "15px"
        p1.yaxis.axis_label_text_font_style = "bold"
        
        
        
        
        range_slider = DateRangeSlider(
            title="Date range",
            start=df['Dates'].iloc[0],
            end=df['Dates'].iloc[-1],
            step=1,
            value=(df['Dates'].iloc[0], df['Dates'].iloc[-1]),
            format="%b %e, %Y"
        )
        range_slider.js_link("value", p1.x_range, "start", attr_selector=0)
        range_slider.js_link("value", p1.x_range, "end", attr_selector=1)
        
        
        layout = layout(
            [
                [range_slider],
                [p1],
            ]
        )
        
        # show result
        plots = layout
        script, div = components(plots)
        
        return script,div
    except:
        print(f'\n Error fetching data of {country_name}')
    
    
    
    

