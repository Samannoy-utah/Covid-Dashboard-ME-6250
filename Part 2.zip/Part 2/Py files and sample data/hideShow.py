# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 13:17:38 2022

@author: Samannoy and Jared
"""
## This function generates the JS code that hides or shows the plots based on dropdown selection

def hideShow2(country, div_dict):
    tempres=""
    text1='if (document.getElementById(\'Chosen_country\').innerHTML=="'
    text2='"){'
    for i in div_dict:
        doctext1='document.getElementById("'
        if i==country:
            div_id=div_dict[i]
            doctextshow='").style.display = "block";'
        else:
            div_id=div_dict[i]
            doctextshow='").style.display = "none";'
        tempres=tempres+doctext1+div_id+doctextshow
        
    endtext='}'
    res=text1+country+text2+tempres+endtext
    return res
