# -*- coding: utf-8 -*-
"""
Created on Sat Dec 10 12:33:37 2022

@author: Samannoy and Jared
"""
## This function plots the data of a 4 sopecific countries based on the parameters.
## std and norm are the 2 types of plots returnable alongside the other parameter
## which specifies the data type: total deaths or daily deaths info

def Multi_country_plotter(plot_type,param):
    
    import readJSON as rj
    import pandas as pd
    
    from bokeh.models import DatetimeTickFormatter, HoverTool, ColumnDataSource, DateRangeSlider
    from bokeh.plotting import figure, show
    from bokeh.io import curdoc
    from bokeh.layouts import row, gridplot, layout
    from bokeh.embed import components
    # from bokeh.themes import Theme
    # from bokeh.themes import built_in_themes
    
    df1 = rj.readJSON("2022-12-11_usa.json")
    df2 = rj.readJSON("2022-12-11_brazil.json")
    df3 = rj.readJSON("2022-12-11_india.json")
    df4 = rj.readJSON("2022-12-11_russia.json")
    
    df1.Dates = pd.to_datetime(df1.Dates,format='%b%d,%Y')    #format the dates from strings
    df2.Dates = pd.to_datetime(df2.Dates,format='%b%d,%Y')
    df3.Dates = pd.to_datetime(df3.Dates,format='%b%d,%Y')
    df4.Dates = pd.to_datetime(df4.Dates,format='%b%d,%Y')
    
    # Fetch data from JSON
    source = ColumnDataSource(df1)
    source2 = ColumnDataSource(df2)
    source3 = ColumnDataSource(df3)
    source4 = ColumnDataSource(df4)
    
    #choose theme
    curdoc().theme = 'light_minimal'
    if plot_type=='total':
        if param=='std':
            p1 = figure(
                title='Cumulative Deaths',
                x_axis_label='Date',
                y_axis_label='Deaths',
                x_axis_type="datetime"
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeaths',
                source=source,
                legend_label='USA',
                color="blue", line_width=2
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeaths',
                source=source2,
                legend_label='Brazil',
                color="red", line_width=2
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeaths',
                source=source3,
                legend_label='India',
                color="green", line_width=2
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeaths',
                source=source4,
                legend_label='Russia',
                color="black", line_width=2
            )
        elif param=='norm':
            p1 = figure(
                title='Cumulative Deaths per 1M',
                x_axis_label='Date',
                y_axis_label='Deaths per 1M',
                x_axis_type="datetime"
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeathsNormalized',
                source=source,
                legend_label='USA',
                color="blue", line_width=2
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeathsNormalized',
                source=source2,
                legend_label='Brazil',
                color="red", line_width=2
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeathsNormalized',
                source=source3,
                legend_label='India',
                color="green", line_width=2
            )
            totalDeaths = p1.line(
                x='Dates',
                y='TotalDeathsNormalized',
                source=source4,
                legend_label='Russia',
                color="black", line_width=2
            )
    elif plot_type=='daily':
        if param=='std':
            p1 = figure(
                title='Daily Deaths',
                x_axis_label='Date',
                y_axis_label='Deaths',
                x_axis_type="datetime"
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeaths',
                source=source,
                legend_label='USA',
                color="blue", line_width=1
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeaths',
                source=source2,
                legend_label='Brazil',
                color="red", line_width=1
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeaths',
                source=source3,
                legend_label='India',
                color="green", line_width=1
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeaths',
                source=source4,
                legend_label='Russia',
                color="black", line_width=1
            )
        elif param=='norm':
            p1 = figure(
                title='Daily Deaths per 1M',
                x_axis_label='Date',
                y_axis_label='Deaths per 1M',
                x_axis_type="datetime"
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeathsNormalized',
                source=source,
                legend_label='USA',
                color="blue", line_width=1
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeathsNormalized',
                source=source2,
                legend_label='Brazil',
                color="red", line_width=1
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeathsNormalized',
                source=source3,
                legend_label='India',
                color="green", line_width=1
            )
            totalDeaths = p1.line(
                x='Dates',
                y='DailyDeathsNormalized',
                source=source4,
                legend_label='Russia',
                color="black", line_width=1
            )
    
    # autohide the toolbar
    p1.toolbar.autohide = True
    
    p1.add_tools(HoverTool(tooltips=('@Dates{%b %e, %Y}: @TotalDeaths'),
              formatters={'@Dates': 'datetime'}))
    
    p1.xaxis[0].formatter = DatetimeTickFormatter(months="%b %e, %Y")
    
    # customize the legend and align to top left
    p1.legend.location = "top_left"
    p1.legend.border_line_width = 2
    p1.legend.border_line_color = "black"
    p1.legend.border_line_alpha = 0.8


    # Design the Title text
    p1.title.align = "center"
    p1.title.text_color = "black"
    p1.title.text_font_size = "20px"
    p1.title.background_fill_color = "white"
    
    # Customize the axes labels
    p1.xaxis.axis_label_text_color="black"
    p1.xaxis.axis_label_text_font_size = "15px"
    p1.xaxis.axis_label_text_font_style = "bold"
    
    p1.yaxis.axis_label_text_color="black"
    p1.yaxis.axis_label_text_font_size = "15px"
    p1.yaxis.axis_label_text_font_style = "bold"
    
    
    range_slider = DateRangeSlider(
        title="Date range",
        start=df1['Dates'].iloc[0],
        end=df1['Dates'].iloc[-1],
        step=1,
        value=(df1['Dates'].iloc[0], df1['Dates'].iloc[-1]),
        format="%b %e, %Y"
    )
    range_slider.js_link("value", p1.x_range, "start", attr_selector=0)
    range_slider.js_link("value", p1.x_range, "end", attr_selector=1)
    
    
    layout = layout(
        [
            [range_slider],
            [p1],
        ]
    )
    
    # show result
    # theme = Theme(json={'attrs' : {'Figure' : {'background_fill_color': 'black'},'Title': {'text_color': 'black'}}})
    plots = layout
    script, div = components(plots)
    
    return script,div